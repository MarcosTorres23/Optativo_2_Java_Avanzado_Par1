/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package Infraestructura.Modelos;

import java.util.Date;

/**
 *
 * @author User
 */
public class Cliente_modelo {
    
    public int IdCliente;
    public int IdPersona;
    public Date FechaIngreso;
    public String Calificacion;
    public String Estado;
    
}
