/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package Infraestructura.Modelos;

import java.util.Date;

/**
 *
 * @author User
 */
public class Movimientos_models {
    public int IdCuenta;
    public int IdMovimiento;
    public Date FechaMovimiento;
    public String TipoMovimiento;
    public Float Saldoanterior;
    public Float Saldoactual;
    public Float Montomovimiento;
    public Float CuentaOrigen;
    public Float CuentaDestino;
    public Float Canal;  
    
}
