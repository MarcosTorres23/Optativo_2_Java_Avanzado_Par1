/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package Infraestructura.Modelos;

import java.util.Date;

/**
 *
 * @author User
 */
public class Cuentas_modelo {
    public int IdCuenta;
    public int IdCliente;
    public String NroCuenta;
    public String TipoCuenta;
    public Date FechaAlta;
    public String Estado;
    public Float Saldo;
    public String NroContrato;
    public Float CostoMantenimiento;
    public String PromedioAcreditacion;
    public String Moneda;   
}
